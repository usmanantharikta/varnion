<div class="container">
<h1>Add Employ </h1>
<?php echo form_open('control_crud/save', 'role="form"'); ?>
  <div class="form-group">
    <label for="name">Name</label>
    <input type="text" class="form-control" id="name" name="name">
  </div>
  <div class="form-group">
    <label for="gender">Gender</label>
    <input type="text" class="form-control" id="gender" name="gender">
  </div>
  <div class="form-group">
    <label for="division">Division</label>
    <input type="text" class="form-control" id="division" name="division">
  </div>
  <div class="form-group">
    <label for="location">Location</label>
    <input type="text" class="form-control" id="location" name="location">
  </div>
  <input type="submit" name="mit" class="btn btn-primary" value="Submit">
  <button type="button" onclick="window.location='<?php echo site_url("control_crud");?>'" class="btn btn-success">Back</button>
</form>
<?php echo form_close(); ?>
</div>
