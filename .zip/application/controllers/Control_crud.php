<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Control_crud extends CI_Controller {
  public function add(){
    $this->load->view('header');
    $this->load->view('addemploy_view');
    $this->load->view('footer');
  }
  public function addpoint_view(){
    $this->load->view('header');
    $this->load->view('addpoint_view');
    $this->load->view('footer');
  }
  public function addredeem_view(){
    $this->load->view('header');
    $this->load->view('addredeem_view');
    $this->load->view('footer');
  }

  public function index(){
    $this->load->view('header');
    $this->load->view('admin_view');
    $this->load->view('footer');
  }

  function save(){
    if($this->input->post('mit')){
      $this->model_crud->add();
      //redirect('control')
    }
    else {
      redirect('Control_crud/add');
    }
  }

  function savepoint(){
    if($this->input->post('submit')){
      $this->model_crud->addpoint();
    }
    else {
      redirect('Control_crud/addpoint_view');
    }
  }

  function saveredeem(){
    if($this->input->post('submit')){
      $this->model_crud->addredeem();
    }
    else {
      redirect('Control_crud/addredeem_view');
    }
  }
}
