<?php
if (!defined('BASEPATH'))
 exit('No direct script access allowed');

class Model_crud extends CI_Model {

 function add() {
  $name = $this->input->post('name');
  $gender = $this->input->post('gender');
  $division = $this->input->post('division');
  $location = $this->input->post('location');
  $data = array(
   'name' => $name,
   'gender' => $gender,
   'division' => $division,
   'location' => $location
  );
  $this->db->insert('person', $data);
 }

function addpoint(){
  $name_employ = $this->input->post('name');
  $date = $this->input->post('date');
  $blue_thumb = $this->input->post('blue_thumb');
  $like_this = $this->input->post('like_this');
  $status =$this->input->post('status');
  $award=$this->input->post('award');
  $data = array(
    'name_employ' => $name_employ,
    'date' =>$date,
    'blue_thumb'=>$blue_thumb,
    'like_this'=>$like_this,
    'status'=>$status,
    'award'=>$award
   );
   $this->db->insert('poin',$data);
}

function addredeem(){
  $code_redeem = $this->input->post('code_redeem');
  $name_redeem = $this->input->post('name_redeem');
  $periode = $this->input->post('periode');
  $quota = $this->input->post('quota');
  $blue_thumb = $this->input->post('blue_thumb');
  $like_this = $this->input->post('like_this');

  $redeem = array(
    'code_redeem'=>$code_redeem,
    'name_redeem'=>$name_redeem,
    'periode'=>$periode,
    'quota'=>$quota
  );

  $data = array(
    'blue_thumb'=>$blue_thumb,
    'like_this'=>$like_this,
   );
   $this->db->insert('redeems',$redeem);
   $this->db->insert('quantity',$data);
}

 }
